# Instructions to build the report from scratch

1. Build the document with latex builder of your choice.
2. Run ``bibtex report-draft``
3. Build the document again
4. The pdfs should be ready!
